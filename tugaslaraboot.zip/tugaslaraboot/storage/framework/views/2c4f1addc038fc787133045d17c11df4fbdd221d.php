<?php $__env->startSection('konten'); ?>

<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Advanced Form Elements
        <small>Preview</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Forms</a></li>
        <li class="active">Advanced Elements</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- SELECT2 EXAMPLE -->

      <div class="row">
        <!-- /.col (left) -->
        <div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-primary">
              <div class="box-header with-border">
                <h3 class="box-title">Quick Example</h3>
              </div>
              <!-- /.box-header -->
              <!-- form start -->
              <form role="form">
                <div class="box-body">
                  <div class="form-group">
                    <!-- select -->
                  <div class="form-group">
                      <label>Select</label>
                      <select class="form-control">
                        <option>Kuliah</option>
                        <option>Refreshing</option>
                        <option>Lab</option>
                        <option>Gosip</option>
                        <option>Tidur</option>
                      </select>
                    </div>

                    <!-- Date and time range -->
                    <div class="form-group">
                        <label>Date and time range:</label>

                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-clock-o"></i>
                          </div>
                          <input type="text" class="form-control pull-right" id="reservationtime">
                        </div>
                        <!-- /.input group -->
                      </div>
                      <!-- /.form group -->

                    <!-- textarea -->
                  <div class="form-group">
                      <label>Deskripsi Kegiatan</label>
                      <textarea class="form-control" rows="3" placeholde  r="Enter ..."></textarea>
                    </div>

                    <div class="form-group">
                        <label>Keterangan</label>
                        <select class="form-control">
                          <option>To Do</option>
                          <option>Break</option>
                          
                        </select>
                      </div>

                <!-- /.box-body -->
  
                <div class="box-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
          </div>
          <!-- /.box -->

    
                 

    </section>
    <!-- /.content -->
  </div>

  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>