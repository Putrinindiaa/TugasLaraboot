<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*
Route::get('/', function () {
    return view('welcome');
});
*/

Route::get('/a', function () {
    return view('header');
});

Route::get('/login','login_controller@login_view')->name('login');
//Route::get('/header','' function ($id) {
Route::get('/form_aktivitas', 'list_aktivitas@form_view');
Route::get('/aktivitas_view', 'list_aktivitas@index');
Route::get('/table_view', 'list_aktivitas@table_view');


//Auth::routes();   
// });